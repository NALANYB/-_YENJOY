package com.yanyu.community;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
